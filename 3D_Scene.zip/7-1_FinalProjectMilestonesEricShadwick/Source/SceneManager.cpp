///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  STUDENT: Eric Shadwick
//  COURSE:  CS-330 Computational Graphics and Visualization
//  DATE:    June 2026
//
//  Clear-glass oil lamp plus desk props (two books, an apple) from the
//  Jeff Conway schoolroom still-life painting.
//
//  LIGHTING NOTES (read from THIS project's fragmentShader.glsl, not assumed):
//   * Ambient: the shader adds each light's ambientColor raw and loops over all
//     4 lights, so ambient values are kept LOW or they stack into a flat fill
//     that drowns the diffuse gradient (the cause of the earlier "flat" look).
//   * Specular has two knobs, and the GLSL names them in a way that invites the
//     wrong guess - so the values below follow what the code on lines 104-105
//     actually does, not the usual Phong convention:
//       - light.focalStrength is the real Phong EXPONENT (the pow() on line
//         104). It sets the highlight's TIGHTNESS: high = small sharp glint,
//         low = broad soft sheen. It is per-light, shared by every material.
//       - material.shininess is just a LINEAR brightness gain (line 105), NOT
//         an exponent. Raising it only makes the highlight brighter until it
//         clips to white; it has no effect on the highlight's size.
//     A flat plane has one normal across its whole surface, so its highlight
//     spreads into a wide band; a curved surface turns away fast and confines
//     the highlight to a spot. That is why the desk needs far less shininess
//     than the glass spheres to avoid a blown-out streak.
//   * The shader has no per-light "bActive" flag - it always reads 4 lights -
//     so we simply leave the unused 4th light at zero and set no bActive.
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	stbi_set_flip_vertically_on_load(true);
	unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);

	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		glGenerateMipmap(GL_TEXTURE_2D);
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0);
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;
		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;
	return false;
}

void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}
	return(textureID);
}

int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}
	return(textureSlot);
}

bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
		return(false);

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
			index++;
	}
	return(true);
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  Registers the surface materials the scene uses. Values are
 *  tuned to this project's shader, which forms specular as
 *  (light.specularIntensity * material.shininess): so a SMALL
 *  shininess gives a controlled highlight, while a large one
 *  blows out to solid white. ambientStrength is modest so the
 *  shaded side stays dark enough to show the form.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	OBJECT_MATERIAL glass;
	glass.tag = "glass";
	glass.ambientColor = glm::vec3(0.30f, 0.32f, 0.36f);
	glass.ambientStrength = 0.20f;
	glass.diffuseColor = glm::vec3(0.55f, 0.58f, 0.64f);    // pulled down from (0.80,0.84,0.90): the brighter base drove the lit face past 1.0 and clipped to white, hiding the frosted pattern above the equator
	glass.specularColor = glm::vec3(0.35f, 0.36f, 0.40f);   // softer than near-white so the highlight does not wash out the texture
	glass.shininess = 40.0f;                                // LINEAR gain, not the exponent: keeps a bright catchlight. The SMALL/tight size of that glint comes from the light's focalStrength (16), not from this value
	m_objectMaterials.push_back(glass);

	OBJECT_MATERIAL brass;
	brass.tag = "brass";
	brass.ambientColor = glm::vec3(0.22f, 0.16f, 0.06f);
	brass.ambientStrength = 0.20f;
	brass.diffuseColor = glm::vec3(0.72f, 0.55f, 0.20f);
	brass.specularColor = glm::vec3(1.0f, 0.92f, 0.62f);
	brass.shininess = 1.6f;                  // same highlight TIGHTNESS as glass (that is set per-light by focalStrength). Lower gain than glass + warm gold specularColor gives a controlled metallic highlight, not a clipped-white one
	m_objectMaterials.push_back(brass);

	OBJECT_MATERIAL wood;
	wood.tag = "wood";
	wood.ambientColor = glm::vec3(0.16f, 0.10f, 0.05f);
	wood.ambientStrength = 0.25f;
	wood.diffuseColor = glm::vec3(0.50f, 0.31f, 0.14f);
	// Varnished desk: a controlled satin sheen so the plane reflects the light
	// rig (Goal 2). A flat plane spreads its highlight into a wide band, so the
	// gain is kept LOW - higher values blew the band out to a white streak. The
	// shader multiplies specular by the wood texture, which warm-tints and
	// darkens it, so the sheen reads as light glinting on grain rather than a
	// flat white patch.
	wood.specularColor = glm::vec3(0.35f, 0.30f, 0.22f);
	wood.shininess = 1.0f;
	m_objectMaterials.push_back(wood);

	OBJECT_MATERIAL wall;
	wall.tag = "wall";
	wall.ambientColor = glm::vec3(0.20f, 0.22f, 0.19f);
	wall.ambientStrength = 0.30f;
	wall.diffuseColor = glm::vec3(0.55f, 0.58f, 0.50f);
	wall.specularColor = glm::vec3(0.04f, 0.04f, 0.04f);
	wall.shininess = 0.2f;                   // flat backdrop
	m_objectMaterials.push_back(wall);

	// Webster dictionary - blue cloth cover. Cloth/paper is essentially matte,
	// so specular is low and shininess (the linear gain) is small: a faint
	// sheen, never a plastic hotspot. diffuseColor is set here AND passed as the
	// flat color in RenderPart, so the cover reads blue regardless of which one
	// the shader's color path consumes.
	OBJECT_MATERIAL bookBlue;
	bookBlue.tag = "book_webster";
	bookBlue.ambientColor = glm::vec3(0.06f, 0.09f, 0.20f);
	bookBlue.ambientStrength = 0.22f;
	bookBlue.diffuseColor = glm::vec3(0.12f, 0.20f, 0.55f);
	bookBlue.specularColor = glm::vec3(0.10f, 0.10f, 0.12f);
	bookBlue.shininess = 0.4f;
	m_objectMaterials.push_back(bookBlue);

	// US History - green cloth cover, same matte treatment as the blue book.
	OBJECT_MATERIAL bookGreen;
	bookGreen.tag = "book_history";
	bookGreen.ambientColor = glm::vec3(0.07f, 0.13f, 0.08f);
	bookGreen.ambientStrength = 0.22f;
	bookGreen.diffuseColor = glm::vec3(0.24f, 0.40f, 0.22f);
	bookGreen.specularColor = glm::vec3(0.10f, 0.11f, 0.10f);
	bookGreen.shininess = 0.4f;
	m_objectMaterials.push_back(bookGreen);

	// Apple - waxy skin, so a little more specular than the books and a
	// slightly brighter catchlight, but still far below the glass.
	OBJECT_MATERIAL apple;
	apple.tag = "apple";
	apple.ambientColor = glm::vec3(0.20f, 0.04f, 0.04f);
	apple.ambientStrength = 0.20f;
	apple.diffuseColor = glm::vec3(0.70f, 0.10f, 0.10f);
	apple.specularColor = glm::vec3(0.45f, 0.35f, 0.30f);
	apple.shininess = 1.2f;
	m_objectMaterials.push_back(apple);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  Places a three-point rig (key / fill / rim) and turns the
 *  shader's lit path on. Ambient values are deliberately low:
 *  the shader adds every light's ambient term raw across all
 *  four light slots, so high ambient would stack into a flat
 *  fill and erase the diffuse gradient that makes a sphere
 *  look round. The unused 4th light is left at zero.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	if (NULL == m_pShaderManager)
		return;

	// Turn the Phong lighting path ON.
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// --- Light 0: KEY light (upper front-left) - main modelling light ---
	m_pShaderManager->setVec3Value("lightSources[0].position", glm::vec3(-6.0f, 8.0f, 6.0f));
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", glm::vec3(0.04f, 0.04f, 0.04f));
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", glm::vec3(0.85f, 0.84f, 0.80f));
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", glm::vec3(1.0f, 1.0f, 1.0f));
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 16.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.5f);

	// --- Light 1: FILL light (front-right, softer) - lifts the shadow side ---
	m_pShaderManager->setVec3Value("lightSources[1].position", glm::vec3(7.0f, 3.5f, 5.0f));
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", glm::vec3(0.03f, 0.03f, 0.04f));
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", glm::vec3(0.30f, 0.32f, 0.38f));
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", glm::vec3(0.3f, 0.3f, 0.35f));
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 12.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.25f);

	// --- Light 2: RIM light (behind/above) - bright edge to pop off the wall ---
	m_pShaderManager->setVec3Value("lightSources[2].position", glm::vec3(0.0f, 7.0f, -7.0f));
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", glm::vec3(0.0f, 0.0f, 0.0f));
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", glm::vec3(0.25f, 0.26f, 0.32f));
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", glm::vec3(0.7f, 0.7f, 0.85f));
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 20.0f);
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.6f);

	// --- Light 3: unused - explicitly zeroed so it contributes nothing ---
	m_pShaderManager->setVec3Value("lightSources[3].position", glm::vec3(0.0f, 0.0f, 0.0f));
	m_pShaderManager->setVec3Value("lightSources[3].ambientColor", glm::vec3(0.0f, 0.0f, 0.0f));
	m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", glm::vec3(0.0f, 0.0f, 0.0f));
	m_pShaderManager->setVec3Value("lightSources[3].specularColor", glm::vec3(0.0f, 0.0f, 0.0f));
	m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 1.0f);
	m_pShaderManager->setFloatValue("lightSources[3].specularIntensity", 0.0f);
}

/***********************************************************
 *  SetTransformations()
 *
 *  Builds the final model matrix. The multiplication order
 *  translation * Rx * Ry * Rz * scale means the scale is
 *  applied first in the object's own local space and the
 *  translation last in world space. Doing scale first keeps
 *  every rotation centered on the part itself, so a part
 *  never swings off its intended axis when it is resized.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	scale = glm::scale(scaleXYZ);
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
}

/***********************************************************
 *  SetShaderColor()
 *
 *  Passes an RGBA colour into the shader and disables texture
 *  sampling. With lighting on, the shader tints this base
 *  colour by the light rig instead of showing it flat.
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	glm::vec4 currentColor;
	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

void SceneManager::SetShaderTexture(std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);
		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
}

void SceneManager::SetShaderMaterial(std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/***********************************************************
 *  LoadSceneTextures()
 *
 *  Loads each image file used by the scene and registers it
 *  under a tag that matches the part's material tag, so the
 *  RenderScene draw helper can bind the right image by tag.
 *  Paths are relative to the project folder (Visual Studio's
 *  working directory), which is where the "textures" folder
 *  lives. The return value of each load is captured so a
 *  missing file is reported on the console while debugging.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;

	bReturn = CreateGLTexture("textures/glass.jpg", "glass");  // clear/textured glass body and chimney
	bReturn = CreateGLTexture("textures/brass.jpg", "brass");  // brass burner collar, ring, and knob
	bReturn = CreateGLTexture("textures/wood.jpg", "wood");    // wooden desk plane (tiled)
	// (the back wall and the book/apple props are left as flat lit colors, so
	//  no extra image files are needed for them)

	// bind the loaded textures to consecutive texture slots (up to 16)
	BindGLTextures();
}

/***********************************************************
 *  PrepareScene()
 *
 *  Loads the primitives the scene draws, then registers
 *  materials and lights so the very first frame is already
 *  lit. The scene reuses a small set of meshes: plane (desk,
 *  wall), cylinder (foot, stem, collar, chimney column),
 *  sphere (font, chimney bell, top flare, apple), torus
 *  (burner ring), and box (the two books).
 ***********************************************************/
void SceneManager::PrepareScene()
{
	LoadSceneTextures();
	DefineObjectMaterials();
	SetupSceneLights();

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadBoxMesh();      // books (Webster, US History) - simple boxes
}

/***********************************************************
 *  RenderScene()
 *
 *  Draws the clear-glass oil lamp from the Conway painting and
 *  the desk props beside it (two books and an apple). The lamp
 *  is built bottom-to-top along the shared X=0, Z=0 axis, with
 *  each vertical level computed from the level beneath it so
 *  the silhouette always meets flush; the props are placed to
 *  the right of the lamp and seated flat on the desk.
 ***********************************************************/
void SceneManager::RenderScene()
{
	// Re-assert lighting each frame so it cannot be lost if some other state
	// change toggles it; cheap insurance against the "flat" failure mode.
	if (NULL != m_pShaderManager)
		m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// ----------------------------------------------------------------------
	// Local draw helper.
	// ----------------------------------------------------------------------
	// Collapses the repeated per-part sequence (set transform, assign material,
	// set colour, draw) into one call so each part below is a single readable
	// line and the pipeline stays identical across every part.
	enum Mesh { CYL, SPH, TOR, PLANE, BOX };

	auto RenderPart = [this](glm::vec3 position,
		glm::vec3 scale,
		glm::vec4 color,
		std::string material,
		Mesh      mesh,
		glm::vec3 rotationDeg = glm::vec3(0.0f),
		glm::vec2 uvScale = glm::vec2(1.0f))
		{
			SetTransformations(scale, rotationDeg.x, rotationDeg.y, rotationDeg.z, position);
			SetShaderMaterial(material);

			// If an image was loaded under this part's tag, texture it; the
			// material (specular/shininess) still drives the highlight because
			// the shader multiplies the lit result by the sampled texture. If
			// no texture exists for the tag (e.g. the wall or the books), fall
			// back to the flat color path so the part still renders correctly.
			if (FindTextureSlot(material) != -1)
			{
				SetShaderTexture(material);
				SetTextureUVScale(uvScale.x, uvScale.y);
			}
			else
			{
				SetShaderColor(color.r, color.g, color.b, color.a);
			}

			switch (mesh)
			{
			case CYL:   m_basicMeshes->DrawCylinderMesh(); break;
			case SPH:   m_basicMeshes->DrawSphereMesh();   break;
			case TOR:   m_basicMeshes->DrawTorusMesh();    break;
			case PLANE: m_basicMeshes->DrawPlaneMesh();    break;
			case BOX:   m_basicMeshes->DrawBoxMesh();      break;
			}
		};

	// ----------------------------------------------------------------------
	// Base colours (lighting tints these; one glass tone keeps the body unified)
	// ----------------------------------------------------------------------
	const glm::vec4 kGlass(0.88f, 0.90f, 0.91f, 1.0f);
	const glm::vec4 kBrass(0.60f, 0.45f, 0.16f, 1.0f);
	const glm::vec4 kWood(0.45f, 0.28f, 0.12f, 1.0f);
	const glm::vec4 kWall(0.55f, 0.58f, 0.50f, 1.0f);
	const glm::vec4 kBookBlue(0.12f, 0.20f, 0.55f, 1.0f);   // Webster
	const glm::vec4 kBookGreen(0.24f, 0.40f, 0.22f, 1.0f);  // US History
	const glm::vec4 kApple(0.70f, 0.10f, 0.10f, 1.0f);

	// ----------------------------------------------------------------------
	// Vertical layout (all values derived, not hand-typed).
	// ----------------------------------------------------------------------
	// "Top" = world-Y of a part's upper surface. Cylinders are positioned by
	// their BASE; spheres by their CENTER, so a sphere's top = center + Ry.
	// kJoin sinks each part slightly into its neighbour to hide the seam.
	const float kJoin = 0.06f;

	const float footY = 0.0f;                       // wide grounding disc
	const float footH = 0.20f;
	const float footTop = footY + footH;

	const float stemH = 0.40f;                      // visible pedestal
	const float stemTop = footTop + stemH;

	const float fontRx = 1.05f;                     // wide lower anchor
	const float fontRy = 0.95f;
	const float fontCtrY = stemTop + fontRy - kJoin;
	const float fontTop = fontCtrY + fontRy;

	const float collarH = 0.15f;                    // brass band
	const float collarY = fontTop - 0.13f;          // embedded into shoulder
	const float collarTop = collarY + collarH;

	const float bellRx = 0.72f;                     // flared chimney base
	const float bellRy = 0.60f;
	const float bellCtrY = collarTop + bellRy - kJoin;
	const float bellTop = bellCtrY + bellRy;

	const float colR = 0.32f;                      // tall slim chimney neck
	const float colH = 1.45f;
	const float colY = bellTop - kJoin;
	const float colTop = colY + colH;

	const float flareRx = 0.46f;                    // flared mouth
	const float flareRy = 0.16f;
	const float flareCtrY = colTop + flareRy - kJoin;

	// ======================================================================
	// BACKDROP
	// ======================================================================

	// Desk: tile the wood texture across the plane (the complex texturing
	// technique) so the grain repeats at a believable plank scale rather than
	// stretching one image over the whole 20x10 surface.
	RenderPart(glm::vec3(0.0f, -0.02f, 0.0f), glm::vec3(20.0f, 1.0f, 10.0f), kWood, "wood", PLANE,
		glm::vec3(0.0f), glm::vec2(4.0f, 4.0f));
	RenderPart(glm::vec3(0.0f, 9.0f, -10.0f), glm::vec3(20.0f, 1.0f, 10.0f), kWall, "wall", PLANE,
		glm::vec3(90.0f, 0.0f, 0.0f));

	// ======================================================================
	// LAMP - GLASS BODY
	// ======================================================================

	RenderPart(glm::vec3(0.0f, footY, 0.0f), glm::vec3(0.55f, footH, 0.55f), kGlass, "glass", CYL);
	RenderPart(glm::vec3(0.0f, footTop - kJoin, 0.0f), glm::vec3(0.40f, stemH, 0.40f), kGlass, "glass", CYL);
	RenderPart(glm::vec3(0.0f, fontCtrY, 0.0f), glm::vec3(fontRx, fontRy, fontRx), kGlass, "glass", SPH);

	// ======================================================================
	// LAMP - BRASS BURNER
	// ======================================================================

	RenderPart(glm::vec3(0.0f, collarY, 0.0f), glm::vec3(0.46f, collarH, 0.46f), kBrass, "brass", CYL);
	RenderPart(glm::vec3(0.0f, collarTop, 0.0f), glm::vec3(0.50f, 0.50f, 0.05f), kBrass, "brass", TOR,
		glm::vec3(90.0f, 0.0f, 0.0f));
	RenderPart(glm::vec3(0.47f, collarY + collarH * 0.5f, 0.0f),
		glm::vec3(0.06f, 0.20f, 0.06f), kBrass, "brass", CYL,
		glm::vec3(0.0f, 0.0f, 90.0f));

	// ======================================================================
	// LAMP - GLASS CHIMNEY (dominant element)
	// ======================================================================

	RenderPart(glm::vec3(0.0f, bellCtrY, 0.0f), glm::vec3(bellRx, bellRy, bellRx), kGlass, "glass", SPH);
	RenderPart(glm::vec3(0.0f, colY, 0.0f), glm::vec3(colR, colH, colR), kGlass, "glass", CYL);
	RenderPart(glm::vec3(0.0f, flareCtrY, 0.0f), glm::vec3(flareRx, flareRy, flareRx), kGlass, "glass", SPH);

	// ======================================================================
	// DESK PROPS - additional objects from the painting (two books + apple)
	// ======================================================================
	// DrawBoxMesh draws a unit cube centered on its position. The scale here is
	// read as (cover width, height, thickness): the WIDE cover faces the camera
	// (+Z) and the thin spine runs front-to-back, so each book reads as a book
	// rather than a domino seen edge-on. The books sit to the right of the lamp
	// and are staggered in depth (Z) the way the painting layers them, so their
	// large footprints never overlap each other or the lamp.
	//
	// Seating: an upright box rests on the desk when its center Y = height * 0.5.
	// A box ROLLED about Z lifts off that, so the leaning green book's center Y
	// is raised to (halfWidth*sin + halfHeight*cos) of the roll angle, which
	// drops its lowest corner exactly onto the desk - it leans without floating.

	// Webster dictionary - tall blue book standing upright, broad cover to camera.
	const float websterH = 3.05f;
	RenderPart(glm::vec3(2.20f, websterH * 0.5f, -0.45f),
		glm::vec3(1.65f, websterH, 0.55f), kBookBlue, "book_webster", BOX);

	// US History - shorter green book leaning toward Webster. The 12-degree Z
	// roll tilts it; center Y = 0.725*sin(12) + 1.225*cos(12) ~= 1.35 seats the
	// low corner on the desk. Set forward in Z so its footprint clears Webster's.
	const float historyRoll = 12.0f;
	RenderPart(glm::vec3(3.50f, 1.35f, 0.15f),
		glm::vec3(1.45f, 2.45f, 0.50f), kBookGreen, "book_history", BOX,
		glm::vec3(0.0f, 0.0f, historyRoll));

	// Apple - single red sphere in the open foreground to the right, set well
	// forward in Z so the larger green book cannot clip it; center Y = radius.
	const float appleR = 0.55f;
	RenderPart(glm::vec3(4.05f, appleR, 1.20f),
		glm::vec3(appleR, appleR, appleR), kApple, "apple", SPH);
}
