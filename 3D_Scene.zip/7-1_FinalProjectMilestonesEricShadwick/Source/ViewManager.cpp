///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  STUDENT: Eric Shadwick
//  COURSE:  CS-330 Computational Graphics and Visualization
//  DATE:    May 2026
//
//  MILESTONE THREE - CAMERA & PROJECTION:
//   * Keyboard navigation: WASD move horizontally / in depth, QE move vertically.
//   * Mouse navigation: cursor changes look direction (yaw/pitch); the scroll
//     wheel adjusts how fast the camera travels.
//   * Projection: P selects perspective (3D), O selects orthographic (2D); the
//     switch happens live at runtime by choosing which projection matrix is
//     built each frame.
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// camera object used for viewing and interacting with
	// the 3D scene
	Camera* g_pCamera = nullptr;

	// these variables are used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// time between current frame and last frame
	float gDeltaTime = 0.0f;
	float gLastFrame = 0.0f;

	// false = perspective (3D) projection, true = orthographic (2D) projection.
	// Toggled live by the P / O keys; PrepareSceneView() reads it each frame.
	bool bOrthographicProjection = false;
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager* pShaderManager)
{
	// initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;
	g_pCamera = new Camera();

	// Framed head-on and level so the lamp fills the view and so the ground
	// plane sits edge-on in orthographic mode (keeping the bottom plane hidden
	// as the rubric asks). Leaving the camera's default Yaw/Pitch keeps Front
	// pointing straight down -Z; the mouse look will take over from there.
	g_pCamera->Position = glm::vec3(0.0f, 3.5f, 10.0f);
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	g_pCamera->Zoom = 45.0f;          // narrower FOV than the old 80 = larger subject
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;
	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}
	glfwMakeContextCurrent(window);

	// Capture and hide the cursor so raw mouse motion can drive the camera look
	// direction without the pointer drifting off the window.
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// register the callback that receives mouse-move events (camera look)
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);

	// register the callback that receives scroll-wheel events (travel speed)
	glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Callback);

	// enable blending for supporting transparent rendering
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return(window);
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  Called by GLFW whenever the mouse moves. Converts the
 *  raw pointer movement into yaw/pitch offsets and feeds
 *  them to the camera so the view turns to follow the mouse.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
	// On the very first event there is no previous position to compare to, so
	// seed it and skip - otherwise the view snaps wildly on the first move.
	if (gFirstMouse)
	{
		gLastX = (float)xMousePos;
		gLastY = (float)yMousePos;
		gFirstMouse = false;
	}

	// horizontal offset = how far the mouse moved in X since the last frame
	float xOffset = (float)xMousePos - gLastX;
	// vertical offset is inverted: screen Y grows downward, but looking "up"
	// should be a positive pitch, so subtract current from last.
	float yOffset = gLastY - (float)yMousePos;

	gLastX = (float)xMousePos;
	gLastY = (float)yMousePos;

	// hand the offsets to the camera, which updates its yaw/pitch and rebuilds
	// its Front vector (pitch is constrained internally to avoid flipping over)
	if (NULL != g_pCamera)
	{
		g_pCamera->ProcessMouseMovement(xOffset, yOffset);
	}
}

/***********************************************************
 *  Mouse_Scroll_Callback()
 *
 *  Called by GLFW on scroll-wheel input. The rubric asks the
 *  wheel to control how fast the camera travels, so each
 *  notch raises or lowers the camera's movement speed rather
 *  than zooming. Speed is clamped so it can never stall at
 *  zero or run away to an unusable rate.
 ***********************************************************/
void ViewManager::Mouse_Scroll_Callback(GLFWwindow* window, double x, double yScrollDistance)
{
	if (NULL != g_pCamera)
	{
		g_pCamera->MovementSpeed += (float)yScrollDistance;

		if (g_pCamera->MovementSpeed < 1.0f)
			g_pCamera->MovementSpeed = 1.0f;
		if (g_pCamera->MovementSpeed > 25.0f)
			g_pCamera->MovementSpeed = 25.0f;
	}
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  Polls the keyboard each frame. WASD drive horizontal and
 *  depth motion, QE drive vertical motion, and P / O switch
 *  the projection mode. All motion is scaled by gDeltaTime so
 *  travel speed is the same regardless of frame rate.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// close the window if the escape key has been pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(m_pWindow, true);
	}

	// no camera = nothing to move
	if (NULL == g_pCamera)
	{
		return;
	}

	// --- horizontal + depth movement (WASD) ---
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);

	// --- vertical movement (QE) ---
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(UP, gDeltaTime);
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);

	// --- projection toggle (P = perspective / 3D, O = orthographic / 2D) ---
	// These just flip the flag; PrepareSceneView() builds the matching matrix
	// on the next frame, so the change is instant and live.
	if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
		bOrthographicProjection = false;
	if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS)
		bOrthographicProjection = true;
}

/***********************************************************
 *  PrepareSceneView()
 *
 *  Builds the per-frame view and projection matrices and
 *  sends them to the shader. The projection branch is what
 *  makes the live perspective/orthographic switch possible.
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// per-frame timing: gDeltaTime keeps movement speed frame-rate independent
	float currentFrame = glfwGetTime();
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// process any keyboard events that may be waiting in the event queue
	ProcessKeyboardEvents();

	// get the current view matrix from the camera
	view = g_pCamera->GetViewMatrix();

	const GLfloat aspect = (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT;

	if (bOrthographicProjection)
	{
		// Orthographic (2D): parallel projection, no perspective foreshortening.
		// orthoScale sets how much vertical world space fits in the view; the
		// width is scaled by aspect so the image is not stretched. Looking at
		// the level, head-on camera, the ground plane is edge-on and stays
		// hidden, which is the correct orthographic result per the rubric.
		const float orthoScale = 4.0f;
		projection = glm::ortho(
			-orthoScale * aspect, orthoScale * aspect,
			-orthoScale, orthoScale,
			0.1f, 100.0f);
	}
	else
	{
		// Perspective (3D): distant objects shrink, near objects grow. Zoom is
		// the field-of-view angle in degrees.
		projection = glm::perspective(
			glm::radians(g_pCamera->Zoom),
			aspect,
			0.1f, 100.0f);
	}

	// if the shader manager object is valid
	if (NULL != m_pShaderManager)
	{
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ViewName, view);
		// set the projection matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);
		// set the view position of the camera into the shader for proper rendering
		m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
	}
}